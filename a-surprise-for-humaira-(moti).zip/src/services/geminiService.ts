import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generateRomanticMessage(userName: string, crushName: string, nickname: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Write a very romantic, short, and sweet message from ${userName} to his crush ${crushName} (whom he affectionately calls "${nickname}"). 
      Context: She was a bit upset with him, and he wants to cheer her up and show how much he cares.
      The message should be poetic, heartfelt, and sincere. Avoid being too cheesy, focus on real feelings.
      Keep it under 60 words.`,
      config: {
        systemInstruction: "You are a professional romantic poet and relationship expert. You excel at writing heartfelt, sincere apologies and romantic messages that touch the soul.",
      }
    });

    return response.text || "You are the most beautiful person I know, Humaira. Please forgive me and let me bring a smile back to your face.";
  } catch (error) {
    console.error("Error generating message:", error);
    return "Every moment without your smile feels like an eternity. You are my everything, Humaira.";
  }
}

export async function generateReasonsWhySheIsSpecial(crushName: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `List 5 unique and very romantic reasons why someone like ${crushName} is special. 
      Make them feel personal and deeply appreciative.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "array",
          items: {
            type: "object",
            properties: {
              reason: { type: "string" },
              description: { type: "string" }
            },
            required: ["reason", "description"]
          }
        }
      }
    });

    return JSON.parse(response.text || "[]");
  } catch (error) {
    return [
      { reason: "Your Smile", description: "It has the power to light up the darkest of my days." },
      { reason: "Your Kindness", description: "The way you care for everyone around you is truly inspiring." },
      { reason: "Our Memories", description: "Every second spent with you is a treasure I hold dear." },
      { reason: "Your Strength", description: "I admire the grace and courage with which you face the world." },
      { reason: "Just Being You", description: "There is no one else in the world quite like you, and that's my favorite thing." }
    ];
  }
}

export async function generatePhotoCaption(crushName: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Write a very short, poetic, and romantic caption for a beautiful photo of ${crushName}. 
      It should be one or two lines max. Something that would make her blush and feel loved.`,
      config: {
        systemInstruction: "You are a master of short-form romantic poetry.",
      }
    });

    return response.text || "Every time I look at you, I find another reason to fall in love all over again.";
  } catch (error) {
    return "In your eyes, I find the home I never knew I was looking for.";
  }
}
