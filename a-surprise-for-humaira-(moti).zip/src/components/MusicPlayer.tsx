import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, Volume2, VolumeX, Music } from 'lucide-react';
import { cn } from '../lib/utils';

export const MusicPlayer: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.5);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play().catch(err => console.error("Playback failed:", err));
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (audioRef.current) {
      audioRef.current.volume = val;
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-8 right-8 z-[100] flex items-center space-x-4 bg-black/40 backdrop-blur-xl border border-white/10 p-4 rounded-3xl shadow-2xl group transition-all hover:bg-black/60"
    >
      <audio 
        ref={audioRef} 
        src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3" 
        loop
      />
      
      <div className="flex items-center space-x-2">
        <div className="w-10 h-10 bg-rose-600/20 rounded-full flex items-center justify-center text-rose-500">
          <Music className={cn("w-5 h-5", isPlaying && "animate-pulse")} />
        </div>
        <div className="hidden group-hover:block transition-all">
          <p className="font-display text-[10px] uppercase tracking-widest text-rose-300">Now Playing</p>
          <p className="font-sans text-xs text-rose-100 font-medium whitespace-nowrap">Meri Zindagi Hai Tu</p>
        </div>
      </div>

      <div className="h-8 w-px bg-white/10 mx-2" />

      <button
        onClick={togglePlay}
        className="w-10 h-10 flex items-center justify-center rounded-full bg-rose-600 text-white hover:bg-rose-500 transition-colors shadow-lg active:scale-95"
      >
        {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-1" />}
      </button>

      <div className="flex items-center space-x-3 w-0 overflow-hidden group-hover:w-32 transition-all duration-500 ease-in-out px-0 group-hover:px-2">
        <button onClick={toggleMute} className="text-rose-400 hover:text-rose-200">
          {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
        </button>
        <input 
          type="range" 
          min="0" 
          max="1" 
          step="0.01" 
          value={volume} 
          onChange={handleVolumeChange}
          className="w-20 accent-rose-500 h-1 bg-white/10 rounded-full appearance-none cursor-pointer"
        />
      </div>
    </motion.div>
  );
};
