import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, HeartOff } from 'lucide-react';
import { cn } from '../lib/utils';

export const LoveQuestion: React.FC = () => {
  const [noButtonPos, setNoButtonPos] = useState({ x: 0, y: 0 });
  const [isAccepted, setIsAccepted] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const moveNoButton = () => {
    if (containerRef.current) {
      const containerRect = containerRef.current.getBoundingClientRect();
      const padding = 50;
      const x = Math.random() * (containerRect.width - 2 * padding) - (containerRect.width / 2 - padding);
      const y = Math.random() * (containerRect.height - 2 * padding) - (containerRect.height / 2 - padding);
      setNoButtonPos({ x, y });
    }
  };

  return (
    <div 
      ref={containerRef}
      className="relative w-full max-w-2xl mx-auto min-h-[400px] flex flex-col items-center justify-center glass rounded-[40px] p-8 overflow-hidden"
    >
      <AnimatePresence mode="wait">
        {!isAccepted ? (
          <motion.div
            key="question"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            className="text-center space-y-12 relative z-10"
          >
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Heart className="w-20 h-20 text-rose-500 mx-auto fill-current" />
            </motion.div>
            
            <h2 className="font-display text-4xl md:text-5xl text-white font-bold leading-tight">
              Humaira,<br />
              <span className="text-rose-400 italic">Do you love me?</span>
            </h2>

            <div className="flex flex-col md:flex-row items-center justify-center gap-6 mt-8">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setIsAccepted(true)}
                className="px-12 py-4 bg-rose-600 text-white rounded-full font-display text-xl tracking-widest uppercase shadow-xl hover:bg-rose-500 transition-colors"
              >
                Yes!
              </motion.button>

              <motion.button
                animate={{ x: noButtonPos.x, y: noButtonPos.y }}
                transition={{ type: 'spring', damping: 15, stiffness: 150 }}
                onMouseEnter={moveNoButton}
                onClick={moveNoButton}
                className="px-12 py-4 glass text-rose-300 rounded-full font-display text-xl tracking-widest uppercase"
              >
                No
              </motion.button>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="accepted"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center space-y-6"
          >
            <div className="flex justify-center space-x-2">
              <motion.div animate={{ y: [0, -20, 0] }} transition={{ repeat: Infinity, duration: 1.5 }}>
                <Heart className="w-16 h-16 text-rose-500 fill-current" />
              </motion.div>
              <motion.div animate={{ y: [0, -20, 0] }} transition={{ repeat: Infinity, duration: 1.5, delay: 0.2 }}>
                <Heart className="w-16 h-16 text-rose-600 fill-current" />
              </motion.div>
              <motion.div animate={{ y: [0, -20, 0] }} transition={{ repeat: Infinity, duration: 1.5, delay: 0.4 }}>
                <Heart className="w-16 h-16 text-rose-500 fill-current" />
              </motion.div>
            </div>
            
            <h2 className="font-display text-5xl text-white font-bold text-glow">
              I Knew It! ❤️
            </h2>
            <p className="font-serif text-2xl text-rose-200 italic">
              "My heart is and always will be yours, Humaira."
            </p>
            
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className="mt-8 text-rose-400 font-display text-sm tracking-[0.2em] uppercase"
            >
              You've made Khan Abdul the happiest person alive!
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Background Hearts */}
      <div className="absolute inset-0 pointer-events-none opacity-5">
        <Heart className="absolute top-10 left-10 w-32 h-32 rotate-12" />
        <Heart className="absolute bottom-10 right-10 w-40 h-40 -rotate-12" />
        <Heart className="absolute top-1/2 left-1/4 w-24 h-24 rotate-45" />
      </div>
    </div>
  );
};
