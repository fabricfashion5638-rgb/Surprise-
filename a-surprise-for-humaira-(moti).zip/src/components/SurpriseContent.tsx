import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Sparkles, RefreshCw, ChevronRight } from 'lucide-react';
import { generateRomanticMessage, generateReasonsWhySheIsSpecial, generatePhotoCaption } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';
import { Camera, Image as ImageIcon, HelpCircle } from 'lucide-react';
import { LoveQuestion } from './LoveQuestion';

interface SurpriseContentProps {
  crushName: string;
  nickname: string;
  userName: string;
}

export const SurpriseContent: React.FC<SurpriseContentProps> = ({ crushName, nickname, userName }) => {
  const [message, setMessage] = useState<string>('');
  const [reasons, setReasons] = useState<{ reason: string; description: string }[]>([]);
  const [caption, setCaption] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab ] = useState<'letter' | 'reasons' | 'gallery' | 'question'>('letter');

  const fetchData = async () => {
    setLoading(true);
    const [msg, res, cap] = await Promise.all([
      generateRomanticMessage(userName, crushName, nickname),
      generateReasonsWhySheIsSpecial(crushName),
      generatePhotoCaption(crushName)
    ]);
    setMessage(msg);
    setReasons(res);
    setCaption(cap);
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const refreshMessage = async () => {
    setLoading(true);
    const msg = await generateRomanticMessage(userName, crushName, nickname);
    setMessage(msg);
    setLoading(false);
  };

  const refreshCaption = async () => {
    setLoading(true);
    const cap = await generatePhotoCaption(crushName);
    setCaption(cap);
    setLoading(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="w-full max-w-4xl mx-auto z-10 px-4"
    >
      <div className="flex flex-wrap justify-center mb-8 gap-4">
        <button
          onClick={() => setActiveTab('letter')}
          className={`px-6 py-2 rounded-full font-display text-sm tracking-widest uppercase transition-all ${
            activeTab === 'letter' ? 'bg-rose-600 text-white shadow-lg' : 'glass text-rose-300 hover:text-rose-100'
          }`}
        >
          Special Letter
        </button>
        <button
          onClick={() => setActiveTab('reasons')}
          className={`px-6 py-2 rounded-full font-display text-sm tracking-widest uppercase transition-all ${
            activeTab === 'reasons' ? 'bg-rose-600 text-white shadow-lg' : 'glass text-rose-300 hover:text-rose-100'
          }`}
        >
          Why You're Special
        </button>
        <button
          onClick={() => setActiveTab('gallery')}
          className={`px-6 py-2 rounded-full font-display text-sm tracking-widest uppercase transition-all ${
            activeTab === 'gallery' ? 'bg-rose-600 text-white shadow-lg' : 'glass text-rose-300 hover:text-rose-100'
          }`}
        >
          Photo Memory
        </button>
        <button
          onClick={() => setActiveTab('question')}
          className={`px-6 py-2 rounded-full font-display text-sm tracking-widest uppercase transition-all ${
            activeTab === 'question' ? 'bg-rose-600 text-white shadow-lg' : 'glass text-rose-300 hover:text-rose-100'
          }`}
        >
          A Question
        </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'letter' ? (
          <motion.div
            key="letter"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="glass rounded-3xl p-8 md:p-12 relative overflow-hidden min-h-[400px] flex flex-col justify-center"
          >
            <div className="absolute top-4 right-4 text-rose-500/20">
              <Sparkles className="w-24 h-24" />
            </div>
            
            <div className="relative z-10">
              <h2 className="font-display text-4xl md:text-5xl mb-8 text-rose-400">
                To My Dearest <span className="italic font-normal">{crushName}</span>
                <span className="block text-xl mt-2 text-rose-300/80">(Moti ❤️)</span>
              </h2>

              <div className="prose prose-invert max-w-none">
                <div className="font-serif text-2xl md:text-3xl leading-relaxed text-rose-100 italic">
                  {loading ? (
                    <div className="space-y-4 animate-pulse">
                      <div className="h-6 bg-rose-900/30 rounded w-3/4" />
                      <div className="h-6 bg-rose-900/30 rounded w-full" />
                      <div className="h-6 bg-rose-900/30 rounded w-2/3" />
                    </div>
                  ) : (
                    <ReactMarkdown>{message}</ReactMarkdown>
                  )}
                </div>
              </div>

              <div className="mt-12 flex items-center justify-between">
                <div className="font-display text-xl text-rose-400">
                  With all my love,<br />
                  <span className="text-2xl">{userName}</span>
                </div>
                
                <button
                  onClick={refreshMessage}
                  disabled={loading}
                  className="flex items-center space-x-2 text-rose-400 hover:text-rose-300 transition-colors disabled:opacity-50"
                >
                  <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
                  <span className="text-sm font-display tracking-widest uppercase">New Magic</span>
                </button>
              </div>
            </div>
          </motion.div>
        ) : activeTab === 'reasons' ? (
          <motion.div
            key="reasons"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
          >
            {reasons.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="glass p-6 rounded-2xl hover:scale-[1.02] transition-transform group"
              >
                <div className="flex items-start space-x-4">
                  <div className="bg-rose-900/30 p-3 rounded-full text-rose-400 group-hover:bg-rose-600 group-hover:text-white transition-colors">
                    <Heart className="w-6 h-6 fill-current" />
                  </div>
                  <div>
                    <h3 className="font-display text-xl text-rose-200 mb-2">{item.reason}</h3>
                    <p className="font-sans text-rose-100/70 leading-relaxed font-light">
                      {item.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6 }}
              className="md:col-span-2 glass p-8 rounded-2xl flex flex-col items-center justify-center text-center space-y-4"
            >
              <Heart className="w-12 h-12 text-rose-500 animate-pulse" />
              <p className="font-display text-2xl text-rose-300 italic">
                "In all the world, there is no heart for me like yours."
              </p>
            </motion.div>
          </motion.div>
        ) : activeTab === 'gallery' ? (
          <motion.div
            key="gallery"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            className="flex flex-col items-center"
          >
            <div className="glass p-4 rounded-[40px] shadow-2xl relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-rose-500 to-rose-900 rounded-[42px] blur-lg opacity-20 group-hover:opacity-40 transition-opacity" />
              
              <div className="relative w-full max-w-[500px] aspect-[3/4] rounded-[32px] overflow-hidden bg-rose-900/10">
                <img 
                  src="https://images.unsplash.com/photo-1518895949257-7621c3c786d7?auto=format&fit=crop&q=80&w=800" 
                  alt={crushName}
                  className="w-full h-full object-cover grayscale-[20%] group-hover:grayscale-0 transition-all duration-700 hover:scale-110"
                />
                
                {/* Visual Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                
                <div className="absolute bottom-8 left-8 right-8 text-center">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={caption}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="space-y-4"
                    >
                      <p className="font-serif text-2xl md:text-3xl text-white italic drop-shadow-lg">
                        {loading ? "Thinking of the perfect words..." : `"${caption}"`}
                      </p>
                    </motion.div>
                  </AnimatePresence>
                </div>
              </div>
            </div>

            <div className="mt-8 flex flex-col items-center space-y-4">
               <button
                  onClick={refreshCaption}
                  disabled={loading}
                  className="flex items-center space-x-2 text-rose-400 hover:text-rose-300 transition-colors disabled:opacity-50 glass px-6 py-3 rounded-full"
                >
                  <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
                  <span className="text-sm font-display tracking-widest uppercase">New Caption</span>
                </button>
                <p className="text-rose-500/50 text-[10px] uppercase tracking-tighter">Your AI personal poet is at work</p>
            </div>
          </motion.div>
        ) : (
          <LoveQuestion />
        )}
      </AnimatePresence>
    </motion.div>
  );
};
