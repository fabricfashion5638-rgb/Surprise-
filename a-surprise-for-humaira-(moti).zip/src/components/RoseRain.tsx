import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';

interface Rose {
  id: number;
  x: number;
  size: number;
  duration: number;
  delay: number;
  rotation: number;
}

export const RoseRain: React.FC = () => {
  const [roses, setRoses] = useState<Rose[]>([]);

  useEffect(() => {
    const newRoses = Array.from({ length: 15 }).map((_, i) => ({
      id: i,
      x: Math.random() * 100,
      size: Math.random() * 30 + 20,
      duration: Math.random() * 5 + 5,
      delay: Math.random() * 2,
      rotation: Math.random() * 360,
    }));
    setRoses(newRoses);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {roses.map((rose) => (
        <motion.div
          key={rose.id}
          initial={{ y: -50, x: `${rose.x}vw`, opacity: 0, rotate: rose.rotation }}
          animate={{
            y: '110vh',
            opacity: [0, 1, 1, 0],
            rotate: rose.rotation + 360,
          }}
          transition={{
            duration: rose.duration,
            repeat: Infinity,
            delay: rose.delay,
            ease: "linear"
          }}
          className="absolute"
          style={{ fontSize: rose.size }}
        >
          🌹
        </motion.div>
      ))}
    </div>
  );
};
