import React from 'react';
import { motion } from 'motion/react';
import { Gift } from 'lucide-react';

interface GiftBoxProps {
  onOpen: () => void;
  isOpen: boolean;
}

export const GiftBox: React.FC<GiftBoxProps> = ({ onOpen, isOpen }) => {
  return (
    <motion.div
      initial={{ scale: 0, rotate: -180 }}
      animate={{ scale: 1, rotate: 0 }}
      transition={{ type: 'spring', damping: 12, stiffness: 100 }}
      className="relative cursor-pointer group"
      onClick={!isOpen ? onOpen : undefined}
    >
      {!isOpen && (
        <>
          <motion.div
            animate={{
              y: [0, -20, 0],
              rotate: [0, 5, -5, 0],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="w-64 h-64 bg-rose-600 rounded-2xl shadow-2xl flex items-center justify-center relative overflow-hidden active:scale-95 transition-transform"
          >
            {/* Ribbons */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-8 h-full bg-rose-400 opacity-80" />
              <div className="h-8 w-full bg-rose-400 absolute opacity-80" />
            </div>
            
            {/* Bow */}
            <div className="absolute -top-4 w-32 h-16 flex justify-around">
              <div className="w-16 h-16 bg-rose-400 rounded-full rotate-45 -mr-4" />
              <div className="w-16 h-16 bg-rose-400 rounded-full -rotate-45 -ml-4" />
            </div>

            <Gift className="w-24 h-24 text-rose-50 relative z-10" />
            
            <div className="absolute bottom-4 text-rose-100 font-display text-sm tracking-widest uppercase">
              Click to Open
            </div>
          </motion.div>
          
          {/* Pulse Effect */}
          <motion.div
            animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0, 0.3] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute -inset-4 border-4 border-rose-500 rounded-3xl pointer-events-none"
          />
        </>
      )}
    </motion.div>
  );
};
