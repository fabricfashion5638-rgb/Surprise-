import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FloatingHearts } from './components/FloatingHearts';
import { RoseRain } from './components/RoseRain';
import { GiftBox } from './components/GiftBox';
import { SurpriseContent } from './components/SurpriseContent';
import { MusicPlayer } from './components/MusicPlayer';
import { Heart } from 'lucide-react';

const App: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const crushName = "Humaira";
  const nickname = "Moti";
  const userName = "Khan Abdul";

  return (
    <div className="min-h-screen relative flex items-center justify-center bg-black overflow-hidden selection:bg-rose-500/30">
      {/* Background Decor */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#3d0a1a_0%,#000_100%)]" />
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/black-paper.png')] opacity-30" />
        
        {/* Animated Glows */}
        <motion.div
          animate={{
            opacity: [0.1, 0.3, 0.1],
            scale: [1, 1.2, 1],
          }}
          transition={{ duration: 8, repeat: Infinity }}
          className="absolute top-1/4 -left-1/4 w-[80vw] h-[80vw] bg-rose-900/20 rounded-full blur-[120px]"
        />
        <motion.div
          animate={{
            opacity: [0.1, 0.2, 0.1],
            scale: [1.2, 1, 1.2],
          }}
          transition={{ duration: 10, repeat: Infinity, delay: 2 }}
          className="absolute bottom-1/4 -right-1/4 w-[60vw] h-[60vw] bg-rose-800/10 rounded-full blur-[100px]"
        />
      </div>

      <FloatingHearts />
      {isOpen && <RoseRain />}
      <MusicPlayer />

      <main className="relative z-10 w-full flex flex-col items-center justify-center min-h-screen py-20">
        <AnimatePresence mode="wait">
          {!isOpen ? (
            <motion.div
              key="intro"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0, scale: 2, filter: 'blur(20px)' }}
              className="text-center space-y-12"
            >
              <div className="space-y-4">
                <motion.h1
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  className="font-display text-5xl md:text-7xl lg:text-8xl text-white font-bold tracking-tight text-glow"
                >
                  For <span className="text-rose-500 italic">{crushName}</span>
                </motion.h1>
                <motion.p
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="font-display text-xl md:text-3xl text-rose-300 italic font-light tracking-wide"
                >
                  A little surprise from <span className="font-semibold text-rose-200">{userName}</span>
                </motion.p>
              </div>

              <div className="flex justify-center">
                <GiftBox isOpen={isOpen} onOpen={() => setIsOpen(true)} />
              </div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.5 }}
                transition={{ delay: 1 }}
                className="mt-8 flex items-center justify-center space-x-2 text-rose-400 font-display text-sm tracking-[0.3em] uppercase"
              >
                <span>Made with love</span>
                <Heart className="w-4 h-4 fill-current" />
              </motion.div>
            </motion.div>
          ) : (
            <div key="surprise" className="w-full">
              <div className="fixed top-8 right-8 z-50">
                 {/* Decorative elements or controls */}
              </div>
              <SurpriseContent 
                crushName={crushName}
                nickname={nickname}
                userName={userName}
              />
            </div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer Branding */}
      <footer className="fixed bottom-6 left-1/2 -translate-x-1/2 z-20 text-rose-500/30 font-display text-xs tracking-widest uppercase pointer-events-none">
        Humaira & Khan &copy; Forever
      </footer>
    </div>
  );
};

export default App;

